export interface WaterIntake {
  water_intake_id: string;
  water_consumed_ml: number;
  water_goal_ml?: number;
  date: string;
}
