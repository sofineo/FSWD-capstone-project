export interface Sleep {
  sleep_id: string;
  sleep_hours: number;
  sleep_goal?: number;
  date: string;
}
